# DAFT figure sources

The Discrete Algebra of the Fourier Transform, Gabriel Peyré.
An adapted English translation of L'algèbre discrète de la transformée de Fourier
(Ellipses, 2004).

Install Python 3.10 or later and run `python -m pip install -r requirements.txt`.
Run any `figures-code/chapter-*/figure-name/generate.py` with Python. Vector PDFs
are written to `figures/`; PNG previews are written to `build/figure-previews/`.
Each generator contains the parameters of the corresponding book figure.

The eight TikZ diagrams additionally require pdfLaTeX with the standalone,
New PX, and TikZ packages. Each diagram includes its `figure.tex` source.

The flower photograph in `data/flower.png` is the supplied input used for the
book's image-processing examples. Shared numerical routines are in `listings/`;
plotting conventions and common inputs are in `tools/`.

Book and gallery: https://mathematical-tours.github.io/daft/
