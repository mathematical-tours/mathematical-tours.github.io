The flower photograph was supplied with the companion MFDS sources.
Numerical examples convert it to grayscale and resize it.
