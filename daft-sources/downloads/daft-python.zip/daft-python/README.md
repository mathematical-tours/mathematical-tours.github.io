# DAFT — Python examples

Gabriel Peyré. Adapted English translation of L'algèbre discrète de la
transformée de Fourier (Ellipses, 2004, ISBN 9782729818678).

Use Python 3.12. From this folder:

    python -m pip install -r requirements.txt
    python -W error tools/verify_programs.py

For an example, add listings/ to Python's module search path:

    import sys
    sys.path.insert(0, "listings")
    from fft_algorithms import fft_dit
    print(fft_dit([1, 2, 0, -1]))

All 88 printed programs are represented by these modules. Shared functions
and imports are included. The tests use independent mathematical references.
Full book and figure sources: https://mathematical-tours.github.io/daft/
