function D1 = floyd(D, verbose)

% floyd - compute shortest path on a 
%   graph using Floyd algorithm.
%   The matrix A is the weighted adjacency matrix
%
%   Copyright (c) 2004 Gabriel Peyr�

if nargin==1
    verbose = 1;
end

N = length(D);

h = waitbar(0,'Computing shortest path');
for k=1:N
     D = min(D,repmat(D(:,k),[1 N])+repmat(D(k,:),[N 1])); 
     waitbar(k/N)
end
close(h);

D1 = D;