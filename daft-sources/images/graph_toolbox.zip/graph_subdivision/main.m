% Test des maillages de subdivision
%
%   Copyright (c) 2003 Gabriel Peyr�


global lang;
if ~strcmp(lang,'eng') % default is french
    lang = 'fr';
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% dessine une sphere de plus en plus subdivis�e

clf;
for s=1:4
    FV = sphere_tri('ico',s,1);
    subplot(1,4,s);
    plot_mesh(FV.vertices,FV.faces);
    
    str = sprintf('Subdivision %d', s);
    title(str);
end

if exist('save_image')
    save_image('graph-subdivision-sphere');
end

disp('Press a key to continue.');
pause;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% build a sphere
FV = sphere_tri('ico',3,1);
vertex = FV.vertices;  % size nbverts x 3
face = FV.faces;     % size nbfaces x 3
nvert = size(vertex,1);
nface = size(face,1);

% the adjacency matrix
A = triangulation2adjacency(face);

% build the laplacian from adjacency matrix
lap = compute_laplacian(A);

% performing SVD
[U,S,V] = svd(lap);
n = length(lap);

p = 3;
clf;
for i=1:p^2
    num = 5*(i-1)+1;
    c = U(:,n-num);
    % rescale c
    c = (c-min(c))/(max(c)-min(c))*255;
    subplot(p,p,i)
    
    patch('vertices',vertex,'faces',face,'FaceVertexCData',c,'edgecolor',[.2 .2 .6]);
    lighting phong; shading interp;
    colormap gray;
    axis square; axis off; 
    
    if strcmp(lang,'eng')==1
        str = ['Eigenvector n�', num2str(num+1)];
    else
        str = ['Vecteur propre n�', num2str(num+1)];
    end
    title(str);
end

if exist('save_image')
    save_image('graph-subdivision-vecteurs-propres');
end

return;
disp('Press a key to continue.');
pause;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Displaying reconstruction.');
% reconstruction 
p = 3;
nbr_max_keep = 20;
clf;
for i=1:p^2
    subplot(p,p,i)

    keep = round(i*nbr_max_keep/p^2); % nbr de pourcent gard�
    vertex2 = U'*vertex;
    % on d�termine le seuil
    vnorm = vertex2(:,1).^2 + vertex2(:,2).^2 + vertex2(:,2).^2;
    vnorms = sort(vnorm); vnorms = reverse(vnorms);
    thresh = vnorms( round(keep/100*nvert) );
    % on enl�ve tous les coeff en dessous du seuil
    mask = vnorm>thresh;
    vertex2(:,1) = vertex2(:,1).*mask;
    vertex2(:,2) = vertex2(:,2).*mask;
    vertex2(:,3) = vertex2(:,3).*mask;
    vertex2 = U*vertex2;

    patch('vertices',vertex2,'faces',face,'facecolor',[cf cf cf],'edgecolor',[ce ce ce]);
    title([num2str(keep), '% des coefficients']);
    lighting phong;
    camlight infinite; 
    camproj('orthographic');
    axis square; axis off; 
end
